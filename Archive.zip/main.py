# Christie Yu, Matt Udry
# CPSC 327 (Object Oriented Programming) Homework 4

from command import CLI

if __name__ == "__main__":
    CLI().run()
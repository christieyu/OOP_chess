# Christie Yu, Matt Udry
# CPSC 327 (Object Oriented Programming) Homework 4

from shared.moves import Move

class ChessMove(Move):
    pass

class Straight(ChessMove):
    pass

class Diagonal(ChessMove):
    pass

class L(ChessMove):
    pass